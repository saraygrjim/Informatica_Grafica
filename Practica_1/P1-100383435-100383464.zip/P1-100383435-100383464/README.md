# Practica 1 

## Contenidos:
- obj: ficheros donde se definen los objetos de manera individual
- scene: contiene main.pov que es el fichero principal
- scene.png: Imagen renderizada con:
```
povray -H2300 -W2100 main.pov
```
